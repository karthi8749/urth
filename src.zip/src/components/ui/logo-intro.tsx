"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import gsap from "gsap";
import { brandPatternCssUrl } from "@/lib/brand-assets";
import { useIntro } from "@/components/providers/homepage-intro-provider";

// The four corner "frame" paths of the URTH mark, taken directly from
// URTH_PRIMARY LOGO BOLD ORANGE.svg
const FRAME_PATHS = [
  "M268.26,142.06h-79.8c-.41,0-.74.33-.74.74v80.54s0,0,0,0h41.65c1.48,0,2.78-.97,3.22-2.39,5.1-16.51,17.86-29.66,34.13-35.28,1.36-.47,2.28-1.74,2.28-3.18v-39.69c0-.41-.33-.74-.74-.74ZM262.26,177.89c0,1.34-.79,2.55-2.02,3.08-14.78,6.41-26.55,18.55-32.51,33.52-.51,1.28-1.75,2.12-3.12,2.12h-30.16s0,0,0,0v-67.81h67.81v29.09Z",
  "M379.39,142.06h-81.27v39.84c0,1.48.97,2.78,2.38,3.22,17.7,5.46,31.52,19.73,36.37,37.68.09.32.38.55.71.55h41.81s0,0,0,0v-81.28s0,0,0,0ZM372.65,216.61h-28.33c-1.38,0-2.62-.84-3.12-2.12-6.19-15.63-18.6-28.05-34.23-34.24-1.28-.51-2.11-1.75-2.11-3.12v-28.33h67.8v67.81Z",
  "M266.73,288.31c-15.64-5.39-28.04-17.75-33.51-33.36-.47-1.35-1.74-2.25-3.17-2.25h-42.33v81.27h0s81.28,0,81.28,0h0v-42.49c0-1.44-.91-2.71-2.27-3.18ZM262.26,327.25h0s-67.81,0-67.81,0c0,0,0,0,0,0v-67.8h0s31.01,0,31.01,0c1.33,0,2.54.78,3.07,2,6.18,14.21,17.49,25.47,31.72,31.59,1.23.53,2.01,1.75,2.01,3.08v31.14Z",
  "M379.39,252.71h-40.51c-1.43,0-2.7.91-3.18,2.26-5.66,16.16-18.77,28.82-35.2,33.9-1.42.44-2.39,1.74-2.39,3.22v41.89h0s81.27,0,81.27,0h0v-81.27h0ZM372.65,327.25h0s-67.8,0-67.8,0h0v-30.4c0-1.38.84-2.61,2.11-3.12,14.88-5.93,26.98-17.61,33.41-32.28.53-1.22,1.74-2,3.07-2h29.2s0,0,0,0v67.8Z",
];

// The two overlapping paths that make up the centre dot mark
const DOT_PATHS = [
  "M322.46,237c0,7.84-2.38,15.11-6.43,21.16-3.37,5-7.88,9.15-13.17,12.07-5.45,3.03-11.72,4.75-18.39,4.75-7.69,0-14.85-2.28-20.83-6.22-4.25-2.77-7.89-6.39-10.73-10.6-4.05-6.05-6.43-13.32-6.43-21.16,0-6.68,1.72-12.94,4.75-18.39,2.99-5.41,7.26-10.01,12.42-13.39,5.98-3.94,13.14-6.22,20.83-6.22,6.67,0,12.94,1.72,18.39,4.75,6.24,3.46,11.4,8.62,14.86,14.86,3.03,5.45,4.75,11.71,4.75,18.39Z",
  "M282.77,274.95c-7.83-.35-14.99-3.05-20.85-7.37-4.85-3.59-8.79-8.28-11.48-13.7-2.78-5.58-4.22-11.92-3.92-18.58.34-7.68,2.94-14.73,7.14-20.53,2.96-4.12,6.73-7.6,11.07-10.25,6.22-3.78,13.6-5.83,21.43-5.48,6.67.3,12.85,2.29,18.16,5.56,5.27,3.22,9.67,7.7,12.82,13,3.67,6.15,5.63,13.41,5.28,21.09-.3,6.66-2.29,12.85-5.56,18.16-3.73,6.08-9.12,11.01-15.51,14.18-5.58,2.78-11.91,4.22-18.58,3.92Z",
];

// The "URTH" + "STUDIO" wordmark paths
const TEXT_PATHS = [
  { d: "M221.79,357.18v23.08c0,6.17-5,11.17-11.17,11.17h-5.64c-6.17,0-11.17-5-11.17-11.17v-23.08s-6.27,0-6.27,0v23.08c0,9.63,7.81,17.44,17.44,17.44h5.64c9.63,0,17.44-7.81,17.44-17.44v-23.08h-6.27Z" },
  { points: "329.4 357.06 312.23 357.06 305.92 357.06 288.76 357.06 288.76 363.36 305.92 363.36 305.92 397.82 312.23 397.82 312.23 363.36 329.4 363.36 329.4 357.06" },
  { points: "373.09 357.06 373.09 374.29 345.06 374.29 345.06 357.06 338.75 357.06 338.75 374.29 338.75 380.59 338.75 397.82 345.06 397.82 345.06 380.59 373.09 380.59 373.09 397.82 379.39 397.82 379.39 380.59 379.39 374.29 379.39 357.06 373.09 357.06" },
  { d: "M273.52,380.59l-.34-.59c4.71-1.54,8.11-5.96,8.11-11.18,0-3.26-1.32-6.19-3.44-8.33-2.13-2.13-5.08-3.44-8.33-3.44h-26.69v40.76h6.3v-17.23h17.12l9.94,17.23h7.28l-9.95-17.23ZM262.54,374.19h-13.42v-10.72h21.81c.62,0,1.5.35,1.93.79,2.86,3.01,2.37,6.42.45,8.35-.97.97-2.31,1.57-3.79,1.57h-6.97Z" },
  { d: "M239.41,420.59c0-1.04-1.14-1.48-3.74-1.48-4.1,0-5.87-1.09-5.87-3.71s2.08-4.08,5.97-4.08c3.58,0,5.97,1.66,5.97,4.16h-2.6c0-1.09-1.35-1.82-3.38-1.82-2.21,0-3.38.6-3.38,1.74,0,.99,1.04,1.38,3.51,1.38,4.29,0,6.1,1.17,6.1,3.82s-2.18,4.23-6.23,4.23c-3.74,0-6.23-1.66-6.23-4.16h2.6c0,1.09,1.46,1.82,3.64,1.82,2.36,0,3.64-.68,3.64-1.9Z" },
  { d: "M249.03,411.57h12.98v2.34h-5.19v10.65h-2.6v-10.65h-5.19v-2.34Z" },
  { d: "M280.07,418.33v-6.75h2.6v6.75c0,3.74-2.65,6.49-6.23,6.49s-6.23-2.75-6.23-6.49v-6.75h2.6v6.75c0,2.34,1.53,4.03,3.64,4.03s3.64-1.69,3.64-4.03Z" },
  { d: "M305,418.07c0,3.74-2.86,6.49-6.75,6.49h-6.49v-12.98h6.49c3.9,0,6.75,2.73,6.75,6.49ZM294.36,422.22h3.9c2.34,0,4.03-1.74,4.03-4.16s-1.69-4.16-4.03-4.16h-3.9v8.31Z" },
  { d: "M313.45,424.56v-12.98h2.6v12.98h-2.6Z" },
  { d: "M331.26,411.26c-3.72,0-6.74,3.05-6.74,6.8s3.02,6.8,6.74,6.8,6.74-3.05,6.74-6.8-3.02-6.8-6.74-6.8ZM331.24,422.56c-2.22,0-4.02-1.98-4.02-4.42s1.8-4.42,4.02-4.42,4.02,1.98,4.02,4.42-1.8,4.42-4.02,4.42Z" },
];

// How far the dot group must move (in the SVG's own coordinate units) so it
// sits at the exact centre of the logo's bounding box once the frame + text
// have faded away. Computed from the dot paths' bounding box vs. the
// viewBox's own centre.
const DOT_RECENTER_X = -1.48;
const DOT_RECENTER_Y = 45;

export function LogoIntro() {
  const [shouldPlay, setShouldPlay] = useState(false);
  // animationDone controls when THIS component unmounts (after its own
  // fade-out finishes). isIntroComplete (context) controls when the
  // header/hero start fading IN — it fires slightly earlier so the two
  // fades overlap instead of leaving a blank gap in between.
  const [animationDone, setAnimationDone] = useState(false);
  const { isIntroComplete, setIntroComplete } = useIntro();
  const containerRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const frameTextRef = useRef<SVGGElement>(null);
  const dotGroupRef = useRef<SVGGElement>(null);
  const patternRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  useEffect(() => {
    if (pathname === "/") {
      setShouldPlay(true);
    } else {
      setIntroComplete(true);
      setAnimationDone(true);
    }
  }, [pathname, setIntroComplete]);

  useEffect(() => {
    if (!shouldPlay) return;

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (prefersReduced) {
      setIntroComplete(true);
      setAnimationDone(true);
      return;
    }

    const container = containerRef.current;
    const logo = logoRef.current;
    const frameText = frameTextRef.current;
    const dotGroup = dotGroupRef.current;
    const pattern = patternRef.current;

    if (!container || !logo || !frameText || !dotGroup || !pattern) return;

    document.body.style.overflow = "hidden";

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        onComplete: () => {
          setAnimationDone(true);
          document.body.style.overflow = "";
        },
      });

      gsap.set(logo, { scale: 1, x: 0, y: 0, opacity: 0 });
      gsap.set(frameText, { opacity: 1 });
      gsap.set(dotGroup, { x: 0, y: 0 });
      gsap.set(pattern, { opacity: 0, scale: 1 });

      tl.to(pattern, { opacity: 0.12, duration: 0.8, ease: "power2.out" })
        .to(logo, { opacity: 1, duration: 1, ease: "power3.out" }, "-=0.4")
        .to(
          logo,
          {
            scale: 1.08,
            duration: 1.5,
            ease: "sine.inOut",
            yoyo: true,
            repeat: 1,
          },
          "-=0.3",
        );

      // Hold
      tl.to({}, { duration: 0.5 });

      const navbarHeight = window.innerWidth <= 768 ? 96 : 112;
      const finalScale = window.innerWidth <= 768 ? 0.25 : 0.3;
      const finalY = -(window.innerHeight / 2) + navbarHeight / 2;

      // Everything below happens TOGETHER, over the same 1.2s: the whole
      // mark shrinks + moves to the nav spot, the frame + text dissolve
      // away, and the dot slides to the centre of its own bounding box —
      // so what's left, exactly in place, IS the nav dot. No image swap.
      tl.addLabel("shrink")
        .to(
          logo,
          { x: 0, y: finalY, scale: finalScale, duration: 1.2, ease: "power3.inOut" },
          "shrink",
        )
        .to(
          frameText,
          { opacity: 0, duration: 1.2, ease: "power2.inOut" },
          "shrink",
        )
        .to(
          dotGroup,
          {
            x: DOT_RECENTER_X,
            y: DOT_RECENTER_Y,
            duration: 1.2,
            ease: "power3.inOut",
          },
          "shrink",
        );

      // Start the header/hero fade-in only AFTER the shrink motion has
      // fully settled (not while it's still moving) — flipping React state
      // mid-motion was causing a re-render that stalled the shrink tween
      // for a frame or two (the "jerk" right as it became the dot).
      tl.addLabel("hide")
        .call(() => setIntroComplete(true), [], "hide")
        .to(
          [container, pattern],
          { opacity: 0, duration: 0.5, ease: "power2.inOut" },
          "hide",
        );

      gsap.to(pattern, {
        scale: 1.05,
        duration: 4,
        ease: "sine.inOut",
        yoyo: true,
        repeat: 1,
      });
    });

    return () => {
      ctx.revert();
      document.body.style.overflow = "";
    };
  }, [shouldPlay, setIntroComplete]);

  if (animationDone) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-100 flex items-center justify-center bg-brown"
      aria-hidden="true"
    >
      {/* Background Pattern */}
      <div
        ref={patternRef}
        className="absolute inset-[-5%] opacity-0 will-change-transform"
      >
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,#4a2a1a_0%,transparent_55%),radial-gradient(ellipse_at_80%_70%,#fa4f0122_0%,transparent_45%),linear-gradient(180deg,#1a1210_0%,#332727_55%,#1a1210_100%)]" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url(${brandPatternCssUrl("orange")})`,
            backgroundSize: "560px",
            backgroundPosition: "center",
          }}
        />
      </div>

      {/* Logo — inlined SVG so the dot can stay in place while the frame
          and wordmark fade around it */}
      <div
        ref={logoRef}
        className="relative z-10 opacity-0 will-change-transform"
      >
        <svg
          viewBox="178 132 210 300"
          className="h-auto w-44 object-cover md:w-52"
          aria-label="URTH Studio"
        >
          <g ref={frameTextRef} fill="#fa4f01">
            {FRAME_PATHS.map((d, i) => (
              <path key={`frame-${i}`} d={d} />
            ))}
            {TEXT_PATHS.map((p, i) =>
              "points" in p ? (
                <polygon key={`text-${i}`} points={p.points} />
              ) : (
                <path key={`text-${i}`} d={p.d} />
              ),
            )}
          </g>
          <g ref={dotGroupRef} fill="#fa4f01">
            {DOT_PATHS.map((d, i) => (
              <path key={`dot-${i}`} d={d} />
            ))}
          </g>
        </svg>
      </div>
    </div>
  );
}
